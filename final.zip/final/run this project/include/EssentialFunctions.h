#ifndef ESSENTIALFUNCTIONS_H_
#define ESSENTIALFUNCTIONS_H_
#include <iostream>
#include <string>
using std::endl;
using std::cout;
using std::cin;
using std::string;

class EssentialFunctions {
 public:
  int i = 0;
  int var = 0;
  int energy = 100;
  void enterAnyKey();
  void clearScreen();
  void enterOption();
  void Consume_Food();
  void showMap();
};
#endif /* ESSENTIALFUNCTIONS_H_ */
