#ifndef SPACE_H_
#define SPACE_H_
#include <iostream>
#include "Events.h"
#include "EssentialFunctions.h"
using std::endl;
using std::cout;
using std::cin;
class Space: public Events,
  public conversation,
  public virtual EssentialFunctions {
 public:
  int levels = 0, scores, inventory = 0;
  void Start();
};
#endif /* SPACE_H_ */
