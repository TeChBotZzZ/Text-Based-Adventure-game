// Minimal source file for a placebo class that does nothing but allows the
// pipeline to pass.

#ifndef PLACEBO_CLASS_H_INCLUDED
#define PLACEBO_CLASS_H_INCLUDED

class PlaceboClass {
 public:
  PlaceboClass();
  virtual ~PlaceboClass();
};

#endif //PLACEBO_CLASS_H_INCLUDED
