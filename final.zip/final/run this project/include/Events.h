#ifndef EVENTS_H_
#define EVENTS_H_
#include <iostream>
#include <string>
#include "Messages.h"
#include "EssentialFunctions.h"
using std::endl;
using std::cout;
using std::cin;
using std::string;
// This class is for implementation of polymorphism
class Events: public virtual EssentialFunctions {
 public:
  void event(int stage);
  void event(int stage, int i);
  void event(int stage, int i, int j);
  void event(int stage, int i, int j, int k);
  void event(int stage, int i, int j, int k, int l);
};
#endif /* EVENTS_H_ */
