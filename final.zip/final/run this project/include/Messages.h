#ifndef MESSAGES_H_
#define MESSAGES_H_
//this class is used for showing conversation
#include <iostream>
#include <string>
#include "EssentialFunctions.h"
using std::endl;
using std::cout;
using std::cin;
using std::string;
class conversation: public virtual EssentialFunctions {
 public:
  void show(int levels);
};

#endif /* MESSAGES_H_ */
