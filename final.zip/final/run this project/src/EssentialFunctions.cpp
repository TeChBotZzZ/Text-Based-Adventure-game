#include "EssentialFunctions.h"
void EssentialFunctions::enterAnyKey() {
  string answer;
  cout << "Enter any key to continue" << endl;
  cin >> answer;
}

void EssentialFunctions::clearScreen() {
  system("clear");
}

void EssentialFunctions::enterOption() {
  cout << "Enter Option::";
  cin >> var;
}

void EssentialFunctions::Consume_Food() {
  energy += 30;
  cout << "Your energy level is now:: " << energy << endl;
  enterAnyKey();
}
void EssentialFunctions::showMap() {
  cout << " Malican Cave(base camp) ----> The lunar maria--->" <<
  " Montes Apenninus-->Tycho crater.\n";
  cout << "   |                                   |                 " <<
  "|                /   \n";
  cout << "   |  <-3Hex way                       |                 " <<
  "|               /   \n";
  cout << "   |                                   |                 " <<
  "|              /   \n";
  cout << "Oceanus Procellarum.           Copernicus crater  " <<
  "Copernicus crater    /   \n";
  cout << "   |                                   |                 " <<
  "|-------------   \n";
  cout << "   |   <-Tekal way                     -----------------  \n";
  cout << "   |                                            " <<
  "|                     \n";
  cout << "    -----------------------                     " <<
  "|                   \n";
  cout << "                           |            " <<
  "prominent crater                      \n";
  cout << "                           |  \n";
  cout << "                           |  \n";
  cout << "                           |  \n";
  cout << "(Destination Point)   King Castle\n";
}
