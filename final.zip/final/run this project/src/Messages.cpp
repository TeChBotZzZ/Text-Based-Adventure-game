#include "Messages.h"

void conversation::show(int levels) {
  switch (levels) {
  case 0: {
  clearScreen();
  cout << "  _    _   _____   _       _____   " <<
  "_____   __  __   _____ \n";
  cout
  << " | |  | | |  ___| | |     /  __ \\ " <<
  "|  _  | |  \\/  | |  ___|         \n";
  cout
  << " | |  | | | |__   | |     | /  \\/ " <<
  "| | | | | .  . | | |__           \n";
  cout
  << " | |/\\| | |  __|  | |     | |     " <<
  "| | | | | |\\/| | |  __|          \n";
  //cout
  //<< " \\\  /\\  / | |___  | |____ |
  //\\__/\\ \\ \\_/ / | |  | | | |___            \n";
  cout
  << "  \\/  \\/  \\____/  \\_____/  \\____/  " <<
  "\\___/  \\_|  |_/ \\____/           \n\n\n\n";
  cout << "IN THIS GAME YOU HAVE TO FIND ALIEN KING'S CASTLE...\n\n";
  cout << "YOU WILL ASLO DO RESEARCH ABOUT ALIENS ON THE PLANET...\n\n";
  enterAnyKey();
  break;
  }
  case 1: {
  clearScreen();
  cout << "YOUR FIRST MISSION IS TO MEET FENDER(ASTROUNAUT)...\n\n";
  enterAnyKey();

  break;
  }
  case 2: {
  clearScreen();
  cout
  << "YOU HAVE PICKED UP FENDER! HE WILL GUIDE YOU WHERE TO GO...\n\n\n";

  cout << "FENDER::HI Mike\n\n";

  cout << "MIKE::HI FENDER\n\n";

  cout << "FENDER::HOW ARE YOU?\n\n";

  cout << "MIKE::I AM GOOD\n\n";

  cout
  << "FENDER::YOU NEED TO BE VERY CAREFUL WHILE WORKING ON THIS MISSION " <<
  "\nBECAUSE ALIENS ARMY IS EVERY WHERE AND IF THEY SEE YOU, THEY " <<
  "IMMEDIATELY KILL YOU\n\n";
  cout
  << "FENDER::I WILL TAKE YOU TO OUR BASE CAMP AND THERE I WILL TELL YOU" <<
  "MORE ON WHAT'S NEXT. \nNOW GO STRAIGHT  AND THEN WE WILL REACH MALLICAN " <<
  "CAVE AND ENTER THAT CAVE(BASE CAMP)";
  cout
  << "TO ENTER THE MALLICAN CAVE YOU WILL NEED TO ANSWER THE PUZZLE\n";
  enterAnyKey();

  break;
  }
  case 3: {
  clearScreen();
  cout
  << "YOU HAVE REACHED THE BASE CAMP... \nENJOY A DINNER WITH FENDER WHILE " <<
  "HE TELLS YOU ABOUT THE MISSION...\n\n";

  cout
  << "FENDER::MIKE I AM GIVING YOU SOME CONSUMABLES " <<
  "AND SOME WEAPONS THAT WILL HELP" <<
  " YOU WITH THE MISSION. YOU WILL ALSO DISGUISE YOURSELF AS A ALIEN \n";

  cout
  << "FENDER::WHEN YOU FIND THE KING'S CASTLE, YOU WILL SEE LOTS OF " <<
  "GUARDS AND IF THEY CAUGHT YOU, THEY WILL TAKE YOU TO THE KING AND " <<
  "THERE YOU WILL BE QUESTIONED. REMEMBER THESE ANSWERS\n";

  cout << "FENDER::1. WHAT IS 3x3?\n";

  cout << "FENDER::ANSWER IS  A\n";

  cout << "FENDER::2. WHAT IS KING'S NAME?\n";

  cout << "FENDER::KING'S NAME IS BAZIN\n";

  cout << "FENDER::3 WHAT IS MOON\n";

  cout << "FENDER::ANSWER IS  CIRCLE \n";

  cout
  << "FENDER::BE SURE TO GIVE RIGHT ANSWER OTHERWISE YOU WILL BE KILLED\n";

  cout
  << "FENDER::I AM REFILLING AN EXTRA OXYGEN CYLINDER AND GIVING FOOD\n";

  cout << "FENDER::KING'S CASTLE IS SOME WHERE BETWEEN KELEKIN\n";

  cout << "FENDER::HERE IS THE MAP\n";

  cout << "MIKE::THANKS FOR HELPING ME\n";

  enterAnyKey();

  break;
  }
  case 4: {
  clearScreen();
  cout << "OPEN THE MAP AND FOLLOW INSTRUCTIONS ACCORDINGLY\n";
  enterAnyKey();

  break;
  }
  case 5: {
  cout << "MOVE TOWARDS THE MISSION...\n";
  cout << "ENTER  KING'S CASTLE...\n";
  cout << "THE GUARDS WILL CATCH YOU AND TAKE YOU TO THE KING... \n";
  cout
  << "DON'T BE SCARED... \nANSWER THE QUESTIONS THAT FENDER TOLD YOU...\n";
  cout
  << "IF YOU ANSWER CORRECTLY YOU WILL BE FREE TO " <<
  "EXPLORE AND IF NOT YOU WILL BE KILLED...\n";
  cout << "SO BE VERY CAREFUL...\n";
  enterAnyKey();
  clearScreen();
  break;
  }
  }
}
