#include "Events.h"
void Events::event(int stage) {
  switch (stage) {
  case 0: {
  cout << "1.Pick space Vehicle\n";
  cout << "2.Return to Space ship\n";
  break;
  }
  case 1: {
  clearScreen();
  cout << "1.Pick Coin Item And Move\n";
  cout << "2.Go Straight\n";
  break;
  case 2:
  {
  clearScreen();
  cout << "1.Go Straight\n";
  cout << "2.PicK and Meet Jhons\n";
  break;
  }
  }
  }
}
// Events For Level 2
void Events::event(int stage, int i) {
  switch (stage) {
  case 0: {
  clearScreen();
  cout << "1.Go Straight\n";
  cout << "2.Take Left\n";
  cout << "3.Take Right \n";
  cout << "4.Take Drop Jhons\n";
  break;
  }
  case 1: {
  clearScreen();
  cout << "1.Go Straight\n";
  cout << "2.Pick Vehicle\n";
  cout << "3.Left Your Vehicle  \n";
  cout << "4.Eat Food\n";
  break;
  }
  case 2: {
  clearScreen();
  cout << "1.Go Straight\n";
  cout << "2.Return\n";
  cout << "3.Enter Mallican Cave \n";
  cout << "3.Drop Jhons\n";
  break;
  }
  case 3: {
  clearScreen();
  cout << "Johns: Wait, what is this strange pink smoke?" << endl;
  cout
  << "\nSwoosh!... a pink entity, name Buu the bubble gum riddler appeared"
  << endl;
  cout << "Buu: If you entertain me well, i will allow you further"
  << endl;
  cout << "Buu: So answer my puzzle and move ahead on your quest" << endl;
  enterAnyKey();
  clearScreen();
  cout << "Solve the puzzle\n" << endl;
  cout << "1+4=5\n";
  cout << "2+5=12\n";
  cout << "3+6=21\n";
  cout << "8+12=?\n";
  break;
  }
  }
}
// Events For Level 3
void Events::event(int stage, int i, int j) {
  switch (stage) {
  case 0: {
  clearScreen();

  cout << "1.Pick Bag\n";
  cout << "2.Pick oxygen Cylinder\n";
  cout << "3.Pick Food\n";
  cout << "4.Pick Map\n";
  break;
  }
  case 1: {
  clearScreen();
  cout << "1.Pick oxygen Cylinder\n";
  cout << "2.Pick Food\n";
  cout << "3.Pick Map\n";
  break;
  }
  case 2: {
  clearScreen();
  cout << "1.Pick Food\n";
  cout << "2.Pick Map\n";
  break;
  }
  case 3: {
  clearScreen();
  cout << "1.Pick Map\n";
  break;
  }
  case 4: {
  clearScreen();
  cout << "1.Pick Vehicle and Move Forward\n";
  break;
  }
  }
}

// Events for Levels 4
void Events::event(int stage, int i, int j, int k) {
  clearScreen();
  string a;
  switch (stage) {
  case 0: {
  clearScreen();
  showMap();
  cout << "\n\nYou have to reach the King's castle" << endl;
  cout << "\nEnter any key to continue" << endl;
  cin >> a;
  break;
  }
  case 1: {
  clearScreen();
  showMap();
  cout << "1.Take Left towards lunarMaria \n";
  cout << "2.Go Straight\n";
  cout << "3.Take Right on 3Way Hex Road towards Oceanus Procellarum. \n";
  cout << "4.Move Backward\n";
  break;
  }
  case 2: {
  clearScreen();
  showMap();
  cout << "1.Take Left\n";
  cout << "2.Keep on Tekal Road \n";
  cout << "3.Take Right\n";
  cout << "4.Move Backward\n";
  break;
  }
  case 3: {
  clearScreen();
  showMap();
  cout << "1.Take Left\n";
  cout << "2.Go Straight\n";
  cout << "3.Take Right\n";
  cout << "4.Move Backward\n";
  break;
  }
  case 4: {
  clearScreen();
  showMap();
  cout << "1.Take Left\n";
  cout << "2.Go Straight\n";
  cout << "3.Take Right\n";
  cout << "4.Move Backward\n";
  break;
  }
  case 5: {
  clearScreen();
  showMap();
  cout << "1.Take Left\n";
  cout << "2.Move Towards Kings Castle\n";
  cout << "3.Take Right\n";
  cout << "4.Move Backward\n";
  cout << "Your Energy is only 10% Take some Food \n";
  break;
  }
  }
}

// Events for level 5
void Events::event(int stage, int i, int j, int k, int l) {
  switch (stage) {
  case 0: {
  clearScreen();
  cout << "1.Enter Kings castle \n";
  cout << "2.Return\n";

  break;
  }
  case 1: {
  clearScreen();
  cout << "What is 3x3?\n";
  cout << "1. A\n";
  cout << "2.9\n";
  cout << "3.P\n";
  cout << "4.0\n";
  break;
  }
  case 2: {
  clearScreen();
  cout << "What is kings Name?\n";
  cout << "1. Clay\n";
  cout << "2.Armuld\n";
  cout << "3.Bazin\n";
  cout << "4.Haryl\n";
  break;
  }
  case 3: {
  clearScreen();
  cout << "What is Moon?\n";
  cout << "1.Planet\n";
  cout << "2.Square\n";
  cout << "3.Dark\n";
  cout << "4.Circle \n";
  break;
  }
  }
}
