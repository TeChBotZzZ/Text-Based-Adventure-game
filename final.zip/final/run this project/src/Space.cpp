#include "Space.h"

void Space::Start() {
  string key;
  string Ans;
  clearScreen();
  cout << "YOU ARE LANDING ON THE MOON... \nSPACESHIP IS ON THE WAY...\n";
  enterAnyKey();
  clearScreen();
  cout << "YOU ARE NOW ON THE MOON...\nGET MOVING...\n";
  enterAnyKey();

  bool play = true, over = false;
  while (play) {
  Over: switch (levels) {
  case 0: {
  show(1);
  clearScreen();
  event(0);
  enterOption();
  if (var == 1) {
  scores = 2;
  event(1);
  enterOption();
  } else {
  cout << "MISSION OVER...\n";
  goto Over;
  }
  if (var == 1) {
  scores += 10;
  cout << "YOU PICKED A COIN, YOUR UPDATED SCORE IS: " << scores
  << endl << endl;
  enterAnyKey();
  clearScreen();
  event(2);
  } else {
  cout << "MISSION OVER...\n";
  goto Over;
  }
  enterOption();
  if (var == 1) {
  clearScreen();
  cout << "YOU HAVE MISSED FENDER... \n";
  cout << "MISSION OVER...\n";

  } else {
  clearScreen();
  energy -= 10;
  cout << "YAHOOOO...OO... \n";
  cout << "MISSION PASSED......\n";
  cout << "YOUR SCORE:: " << scores + 10 << endl;
  cout << "YOUR ENERGY:: " << energy << endl;
  cout << "YOUR INVENTORY:: " << inventory << endl;
  levels = 1;
  enterAnyKey();
  clearScreen();
  cout << "DO YOU WANT TO PLAY NEXT LEVEL? Y/N::";
  cin >> Ans;
  if (Ans == "Y" || Ans == "y" || Ans == "n" || Ans == "N") {
  } else {
  while (Ans != "Y" && Ans != "y" && Ans != "n" && Ans != "N") {
  cout << "Enter Y for Yes or N for No\n";
  cin >> Ans;
  }
  }
  if (Ans == "Y" || Ans == "y") {
  play = true;
  }
  if (Ans == "N" || Ans == "n") {
  play = false;
  }
  }
  break;
  }

  // For level 2

  case 1: {
  show(2);

  event(0, 0);
  enterOption();
  //passing of stage 1
  if (var == 1) {
  scores += 5;
  event(var, 0);
  enterOption();
  } else {
  var = 0;
  cout << "Mission Over\n";
  cout << "Follow Jhons Instructions\n";
  cout << "Mission Over\n";

  goto Over;
  }
  //passing of stage 2
  if (var == 1) {
  scores += 10;
  event(2, 0);
  enterOption();
  } else {
  cout << "Mission Over\n";
  cout << "Follow Jhons Instructions\n";
  cout << "Mission Over\n";
  over = true;
  goto Over;
  }
  if (var == 3) {
  cout
  << "You have successfully reached the Mallican Cave(base Camp)"
  << endl;
  enterAnyKey();
  clearScreen();
  event(3, 0);
  enterOption();
  } else {
  cout << "Mission Over\n";
  over = true;
  goto Over;
  }
  if (var != 104) {
  clearScreen();
  cout << "Follow Jhons Instruction\n";
  cout << "Mission Over\n";
  } else {
  clearScreen();
  cout << "Yahoo!!! \n";
  cout << "Mission Passed\n";
  scores = scores + 10;
  cout << "Your Scores:: " << scores << endl;
  levels = 2;
  cout << "Do you Want to Play next Level Y/N::";
  cin >> Ans;
  if (Ans != "Y" || Ans != "y" || Ans != "n" || Ans != "N") {
  while (Ans != "Y" && Ans != "y" && Ans != "n" && Ans != "N") {
  cout << "Enter Y for Yes or N for No\n";
  cin >> Ans;
  }
  }
  if (Ans == "Y" || Ans == "y") {
  play = true;
  }
  if (Ans == "N" || Ans == "n") {
  play = false;
  }
  }

  break;
  }
  // For Level 3
  case 2: {
  show(3);
  event(0, 0, 0);
  enterOption();
  if (var == 1) {
  event(1, 0, 0);
  cout << "Players Inventory::" << inventory++ << endl;
  enterOption();
  } else {
  cout << "Pick the items in sequence" << endl;
  enterAnyKey();
  goto Over;
  }
  if (var == 1) {
  event(2, 0, 0);
  cout << "Players Inventory::" << inventory++ << endl;
  enterOption();
  } else {
  cout << "Pick the items in sequence" << endl;
  enterAnyKey();
  goto Over;
  }

  if (var == 1) {
  event(3, 0, 0);
  cout << "Players Inventory::" << inventory++ << endl;
  enterOption();
  } else {
  cout << "Pick the items in sequence" << endl;
  enterAnyKey();
  goto Over;
  }
  if (var == 1) {
  clearScreen();
  cout << "Yahoo!!! \n";
  cout << "Mission Passed\n";
  scores = scores + 20;
  levels = 3;
  cout << "Your Scores:: " << scores << endl;
  cout << "Do you Want to Play next Level Y/N::";
  cin >> Ans;
  if (Ans != "Y" && Ans != "y" && Ans != "n" && Ans != "N") {
  while (Ans != "Y" || Ans != "y" || Ans != "n" || Ans != "N") {
  cout << "Enter Y for Yes or N for No\n";
  cin >> Ans;
  }
  }
  if (Ans == "Y" || Ans == "y") {
  play = true;
  }
  if (Ans == "N" || Ans == "n") {
  play = false;
  }
  }

  break;
  }
  //For Level 4
  case 3: {
  show(4);
  event(0, 0, 0, 0);
  event(1, 0, 0, 0);
  enterOption();
  clearScreen();
  if (var == 3) {
  event(2, 0, 0, 0);
  enterOption();
  } else {
  cout << "Choose the right Way according to Map" << endl;
  enterAnyKey();
  goto Over;
  }
  if (var == 2) {
  event(3, 0, 0, 0);
  enterOption();

  } else {
  cout << "Choose the right Way according to Map" << endl;
  enterAnyKey();
  goto Over;
  }
  if (var == 1) {
  event(4, 0, 0, 0);
  enterOption();
  } else {
  cout << "Choose the right Way according to Map" << endl;
  enterAnyKey();
  goto Over;
  }
  if (var == 3) {
  event(5, 0, 0, 0);
  enterOption();

  } else {
  cout << "Choose the right Way according to Map" << endl;
  enterAnyKey();
  goto Over;
  }
  if (var == 2) {
  clearScreen();
  cout
  << " To Move Beyond the Castle Door You will have to solve Puzzle \n";
  cout << "6=30\n";
  cout << "5=20\n";
  cout << "4=12\n";
  cout << "3=?\n";
  cout << "Enter Your Ans::";
  cin >> var;
  } else {
  cout << "Choose the right Way according to Map" << endl;
  enterAnyKey();
  goto Over;
  }

  if (var == 6) {
  clearScreen();
  cout << "Yahoo!!! \n";
  cout << "Mission Passed\n";
  scores = scores + 20;
  cout << "Your Scores:: " << scores << endl;
  levels = 4;
  cout << "Do you Want to Play next Level Y/N::";
  cin >> Ans;
  if (Ans != "Y" || Ans != "y" || Ans != "n" || Ans != "N") {
  while (Ans != "Y" && Ans != "y" && Ans != "n" && Ans != "N") {
  cout << "Enter Y for Yes or N for No\n";
  cin >> Ans;
  }
  }
  if (Ans == "Y" || Ans == "y") {
  play = true;
  }
  if (Ans == "N" || Ans == "n") {
  play = false;
  }
  }
  enterAnyKey();
  break;
  }

  //For level 5
  case 4: {
  //string Ans;
  clearScreen();
  cout << "Take Some Food to Boost yourself\n";
  cout << "Do You want to consume Food Y/N\n";
  cin >> Ans;
  if (Ans == "Y" || Ans == "y") {
  Consume_Food();
  }
  clearScreen();
  cout
  << "Oxygen Level is droping in Your Cylinder Its " <<
  "time to replace witha filled ones \n";
  cout << "Do You want to change your cylinder Y/N\n";
  cin >> Ans;
  if (Ans == "Y" || Ans == "y") {
  energy = energy + 10;
  cout << "Your Energy level  ::" << energy << endl;
  }
  cout << "Enter any key to continue::" << endl;
  cin >> key;
  clearScreen();
  cout << "Some Items in your bag are of no use Please Drop some \n";
  cout << "Do want to drop some items Y/N\n";
  cin >> Ans;
  while (inventory > 0) {
  if (Ans == "Y" || Ans == "y") {
  inventory--;
  cout << "Players Inventory:: " << inventory << endl;
  if (inventory != 0) {
  cout << "Do want to drop some items Y/N\n";
  cin >> Ans;
  }
  } else {
  cout << "drop all items" << endl;
  if (inventory != 0) {
  cout << "Do want to drop some items Y/N\n";
  cin >> Ans;
  }
  }
  }
  levels = 5;
  }

  // For Level 6
  case 5: {
  clearScreen();
  show(5);
  event(0, 0, 0, 0, 0);
  enterOption();

  if (var == 1) {
  cout
  << "Your are Caught by Soldiers and taken infront " <<
  "of king make sure to give right Anss\n";
  event(1, 0, 0, 0, 0);
  enterOption();
  } else {
  cout << "Mission Over\n";
  goto Over;
  }
  if (var == 1) {
  event(2, 0, 0, 0, 0);
  enterOption();
  } else {
  cout << "Mission Over\n";
  goto Over;
  }
  if (var == 3) {
  event(3, 0, 0, 0, 0);
  enterOption();
  } else {
  cout << "Mission Over\n";
  goto Over;
  }
  if (var == 4) {
  clearScreen();
  cout << "Yahoo!!! \n";
  cout << "Mission Passed\n";
  scores = scores + 100;
  cout << "Your Scores:: " << scores << endl;
  cout << "You have won the game, Yeehaw!" << endl;
  cout << "\nYou will exit the game after entering any key"
  << endl;
  int jk;
  cin >> jk;
  play = false;
  } else {
  cout << "Mission Over\n";
  goto Over;
  }

  break;
  }
  }
  }
}
