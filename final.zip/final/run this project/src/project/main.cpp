#include<iostream>
#include "Space.h"
int main() {
  Space s;
  s.show(0);
  s.Start();
  return 0;
}
