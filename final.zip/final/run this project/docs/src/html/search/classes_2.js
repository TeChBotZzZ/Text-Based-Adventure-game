var searchData=
[
  ['placeboclass_37',['PlaceboClass',['../class_placebo_class.html',1,'']]]
];
