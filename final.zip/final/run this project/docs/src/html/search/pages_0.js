var searchData=
[
  ['assignment_20d_68',['Assignment D',['../md__r_e_a_d_m_e.html',1,'']]]
];
