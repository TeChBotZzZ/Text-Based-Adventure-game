var searchData=
[
  ['placeboclass_57',['PlaceboClass',['../class_placebo_class.html#af925dad97c04ad658af03baa6e44da4d',1,'PlaceboClass']]]
];
