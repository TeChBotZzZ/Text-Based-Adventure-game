var searchData=
[
  ['i_14',['i',['../class_essential_functions.html#aef74382ee1288f6d6cd700751a08be16',1,'EssentialFunctions']]],
  ['inventory_15',['inventory',['../class_space.html#a439e81d00f66bd1e03d5ff7f63bcd554',1,'Space']]]
];
