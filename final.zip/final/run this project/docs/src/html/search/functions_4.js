var searchData=
[
  ['show_58',['show',['../classconversation.html#a9f2a8e714cc394115b96d25891dfcb5d',1,'conversation']]],
  ['showmap_59',['showMap',['../class_essential_functions.html#a08a23e660213b2dcbde0061788c77a66',1,'EssentialFunctions']]],
  ['start_60',['Start',['../class_space.html#a537b3e6c7d75a99db67ae87c7b1b26ab',1,'Space']]]
];
