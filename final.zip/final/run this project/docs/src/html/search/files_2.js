var searchData=
[
  ['placeboclass_2eh_45',['PlaceboClass.h',['../_placebo_class_8h.html',1,'']]]
];
