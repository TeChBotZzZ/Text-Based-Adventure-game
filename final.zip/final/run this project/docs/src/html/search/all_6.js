var searchData=
[
  ['placeboclass_20',['PlaceboClass',['../class_placebo_class.html',1,'PlaceboClass'],['../class_placebo_class.html#af925dad97c04ad658af03baa6e44da4d',1,'PlaceboClass::PlaceboClass()']]],
  ['placeboclass_2eh_21',['PlaceboClass.h',['../_placebo_class_8h.html',1,'']]]
];
