var classspace =
[
    [ "Start", "classspace.html#ab70620b2af8685fba7bb258bedccf152", null ],
    [ "inventory", "classspace.html#af200e26f431588dfdd477839cbbdb4bd", null ],
    [ "levels", "classspace.html#a43efc6eef5879cdfd4c568fd63ecd29d", null ],
    [ "scores", "classspace.html#a67e834a892f458af74b822b98071cac0", null ]
];