var files_dup =
[
    [ "EssentialFunctions.cpp", "_essential_functions_8cpp.html", null ],
    [ "EssentialFunctions.h", "_essential_functions_8h.html", [
      [ "EssentialFunctions", "class_essential_functions.html", "class_essential_functions" ]
    ] ],
    [ "Events.cpp", "_events_8cpp.html", null ],
    [ "Events.h", "_events_8h.html", [
      [ "Events", "class_events.html", "class_events" ]
    ] ],
    [ "src/project/main.cpp", "src_2project_2main_8cpp.html", "src_2project_2main_8cpp" ],
    [ "test/main.cpp", "test_2main_8cpp.html", "test_2main_8cpp" ],
    [ "Messages.cpp", "_messages_8cpp.html", null ],
    [ "Messages.h", "_messages_8h.html", [
      [ "conversation", "classconversation.html", "classconversation" ]
    ] ],
    [ "PlaceboClass.h", "_placebo_class_8h.html", [
      [ "PlaceboClass", "class_placebo_class.html", "class_placebo_class" ]
    ] ],
    [ "Space.cpp", "_space_8cpp.html", null ],
    [ "Space.h", "_space_8h.html", [
      [ "Space", "class_space.html", "class_space" ]
    ] ]
];