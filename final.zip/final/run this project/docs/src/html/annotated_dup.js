var annotated_dup =
[
    [ "conversation", "classconversation.html", "classconversation" ],
    [ "EssentialFunctions", "class_essential_functions.html", "class_essential_functions" ],
    [ "Events", "class_events.html", "class_events" ],
    [ "PlaceboClass", "class_placebo_class.html", "class_placebo_class" ],
    [ "Space", "class_space.html", "class_space" ]
];