var class_essential_functions =
[
    [ "clearScreen", "class_essential_functions.html#aea37fbd8a55b0b92fed2b6b3de794875", null ],
    [ "Consume_Food", "class_essential_functions.html#ac48feee97e93ee6f432bbb3c997a213e", null ],
    [ "enterAnyKey", "class_essential_functions.html#aef3da87e44434477cab0084a4489e29a", null ],
    [ "enterOption", "class_essential_functions.html#a97b59555d337865dbb4d3ba37d8bbebd", null ],
    [ "showMap", "class_essential_functions.html#a08a23e660213b2dcbde0061788c77a66", null ],
    [ "energy", "class_essential_functions.html#aa519cbd28f4f5be79b4785d8cf385fe5", null ],
    [ "i", "class_essential_functions.html#aef74382ee1288f6d6cd700751a08be16", null ],
    [ "var", "class_essential_functions.html#aeaa3fcdb027e089da31c78fb017011c5", null ]
];