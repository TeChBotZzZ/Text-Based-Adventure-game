var class_placebo_class =
[
    [ "PlaceboClass", "class_placebo_class.html#af925dad97c04ad658af03baa6e44da4d", null ],
    [ "~PlaceboClass", "class_placebo_class.html#a61ccfd3b03de89d0850078f355199862", null ]
];