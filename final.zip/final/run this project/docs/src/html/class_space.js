var class_space =
[
    [ "Start", "class_space.html#a537b3e6c7d75a99db67ae87c7b1b26ab", null ],
    [ "inventory", "class_space.html#a439e81d00f66bd1e03d5ff7f63bcd554", null ],
    [ "levels", "class_space.html#af21138d84eb23d04cabe08ab50d41538", null ],
    [ "scores", "class_space.html#a620ba957e647039138d6d3038535c1b3", null ]
];