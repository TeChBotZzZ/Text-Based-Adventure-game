var hierarchy =
[
    [ "EssentialFunctions", "class_essential_functions.html", [
      [ "conversation", "classconversation.html", [
        [ "Space", "class_space.html", null ]
      ] ],
      [ "Events", "class_events.html", [
        [ "Space", "class_space.html", null ]
      ] ],
      [ "Space", "class_space.html", null ]
    ] ],
    [ "PlaceboClass", "class_placebo_class.html", null ]
];